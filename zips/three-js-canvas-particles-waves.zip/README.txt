A Pen created at CodePen.io. You can find this one at https://codepen.io/deathfang/pen/WxNVoq.

 http://www.css88.com/demo/threejs-waves/